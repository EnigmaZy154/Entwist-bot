package voice

import (
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"strings"
	"time"
)

// VoipMsClient - Client for voip.ms REST API v1
// API Docs: https://voip.ms/m/apidocs.php
type VoipMsClient struct {
	APIKey     string
	APISecret string
	Account    string
	BaseURL    string
	Client     *http.Client
}

// VoipMsCallRequest - Request structure for making calls
type VoipMsCallRequest struct {
	From     string // Caller ID number (must be verified on your voip.ms account)
	To       string // Destination number in +E164 format
	Timeout  int    // Ring timeout in seconds (default: 60)
	AudioURL string // URL to audio file to play
}

// VoipMsCallResponse - Response from makeCall API
type VoipMsCallResponse struct {
	Status   string `json:"status"`
	CallID   string `json:"callid,omitempty"`
	Message  string `json:"message,omitempty"`
	Domain   string `json:"domain,omitempty"`
	Summary  string `json:"summary,omitempty"`
}

// VoipMsBalanceResponse - Response from getBalance API
type VoipMsBalanceResponse struct {
	Status   string `json:"status"`
	Balance  string `json:"balance"`
	Currency string `json:"currency"`
}

// VoipMsDIDsResponse - Response for DID information
type VoipMsDIDsResponse struct {
	Status  string `json:"status"`
	DIDs    []struct {
		DID            string `json:"did"`
		Routing        string `json:"routing"`
		CNAM           string `json:"cnam"`
		CNAMOverride   string `json:"cnam_override"`
		Label          string `json:"label"`
		POP            string `json:"pop"`
		FailoverRoute  string `json:"failover_route"`
		Tech           string `json:"tech"`
		State          string `json:"state"`
		Setup          string `json:"setup"`
		Monthly        string `json:"monthly"`
		PerMin         string `json:"per_min"`
		BillingIncrem  string `json:"billing_increment"`
		BillingType    string `json:"billing_type"`
		AllowIncoming  string `json:"allow_incoming"`
	} `json:"dids"`
}

// VoipMsMessageResponse - Response for SMS/MMS send
type VoipMsMessageResponse struct {
	Status       string `json:"status"`
	Deliverable  string `json:"deliverable,omitempty"`
	FailedReason string `json:"failed_reason,omitempty"`
	MessageID    string `json:"message_id,omitempty"`
}

// NewVoipMsClient - Creates a new voip.ms API client
func NewVoipMsClient(apiKey, apiSecret, account string) *VoipMsClient {
	return &VoipMsClient{
		APIKey:     apiKey,
		APISecret: apiSecret,
		Account:    account,
		BaseURL:    "https://voip.ms/api/v1/rest.php",
		Client: &http.Client{
			Timeout: 30 * time.Second,
		},
	}
}

// buildParams - Build common parameters for all API calls
func (v *VoipMsClient) buildParams(method string) map[string]string {
	return map[string]string{
		"api_key":     v.APIKey,
		"api_secret":  v.APISecret,
		"account":     v.Account,
		"method":      method,
	}
}

// doRequest - Execute an API request
func (v *VoipMsClient) doRequest(method string, params map[string]string) ([]byte, error) {
	// Build URL with query parameters
	baseURL, _ := url.Parse(v.BaseURL)
	queryParams := url.Values{}
	
	// Add custom params if provided
	if params != nil {
		for k, va := range params {
			queryParams.Add(k, va)
		}
	}
	
	queryParams.Add("api_key", v.APIKey)
	queryParams.Add("api_secret", v.APISecret)
	queryParams.Add("account", v.Account)
	queryParams.Add("method", method)
	baseURL.RawQuery = queryParams.Encode()

	// Create GET request
	req, err := http.NewRequest("GET", baseURL.String(), nil)
	if err != nil {
		return nil, fmt.Errorf("failed to create request: %w", err)
	}

	req.Header.Set("Accept", "application/json")

	resp, err := v.Client.Do(req)
	if err != nil {
		return nil, fmt.Errorf("request failed: %w", err)
	}
	defer resp.Body.Close()

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return nil, fmt.Errorf("failed to read response: %w", err)
	}

	return body, nil
}

// postRequest - Execute a POST API request
func (v *VoipMsClient) postRequest(method string, params map[string]string) ([]byte, error) {
	// Build URL with query parameters
	baseURL, _ := url.Parse(v.BaseURL)
	queryParams := url.Values{}
	queryParams.Add("api_key", v.APIKey)
	queryParams.Add("api_secret", v.APISecret)
	queryParams.Add("account", v.Account)
	queryParams.Add("method", method)
	
	// Add additional params
	for k, va := range params {
		queryParams.Add(k, va)
	}
	
	baseURL.RawQuery = queryParams.Encode()

	// Create POST request
	req, err := http.NewRequest("POST", baseURL.String(), nil)
	if err != nil {
		return nil, fmt.Errorf("failed to create request: %w", err)
	}

	req.Header.Set("Accept", "application/json")

	resp, err := v.Client.Do(req)
	if err != nil {
		return nil, fmt.Errorf("request failed: %w", err)
	}
	defer resp.Body.Close()

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return nil, fmt.Errorf("failed to read response: %w", err)
	}

	return body, nil
}

// MakeCall - Initiate an outbound call
// Docs: https://voip.ms/m/apidocs.php (makeCall method)
func (v *VoipMsClient) MakeCall(req VoipMsCallRequest) (*VoipMsCallResponse, error) {
	params := map[string]string{
		"caller_id":    req.From,
		"called_number": req.To,
		"timeout":      fmt.Sprintf("%d", req.Timeout),
	}
	
	// Optional: URL to audio file
	if req.AudioURL != "" {
		params["audio_url"] = req.AudioURL
	}

	body, err := v.postRequest("makeCall", params)
	if err != nil {
		return nil, fmt.Errorf("makeCall failed: %w", err)
	}

	var resp VoipMsCallResponse
	if err := json.Unmarshal(body, &resp); err != nil {
		return nil, fmt.Errorf("failed to parse response: %w", err)
	}

	if resp.Status != "success" {
		return nil, fmt.Errorf("voip.ms error: %s - %s", resp.Status, resp.Message)
	}

	return &resp, nil
}

// HangupCall - Hang up a specific call by ID
func (v *VoipMsClient) HangupCall(callID string) error {
	params := map[string]string{
		"callid": callID,
	}

	body, err := v.postRequest("cancelCall", params)
	if err != nil {
		return fmt.Errorf("cancelCall failed: %w", err)
	}

	var resp VoipMsCallResponse
	if err := json.Unmarshal(body, &resp); err != nil {
		return fmt.Errorf("failed to parse response: %w", err)
	}

	if resp.Status != "success" {
		return fmt.Errorf("voip.ms error: %s - %s", resp.Status, resp.Message)
	}

	return nil
}

// GetCallStatus - Get status of a call
func (v *VoipMsClient) GetCallStatus(callID string) (*VoipMsCallResponse, error) {
	params := map[string]string{
		"callid": callID,
	}

	body, err := v.doRequest("getCallInfo", params)
	if err != nil {
		return nil, fmt.Errorf("getCallInfo failed: %w", err)
	}

	var resp VoipMsCallResponse
	if err := json.Unmarshal(body, &resp); err != nil {
		return nil, fmt.Errorf("failed to parse response: %w", err)
	}

	return &resp, nil
}

// GetBalance - Get account balance
func (v *VoipMsClient) GetBalance() (*VoipMsBalanceResponse, error) {
	body, err := v.doRequest("getBalance", nil)
	if err != nil {
		return nil, fmt.Errorf("getBalance failed: %w", err)
	}

	var resp VoipMsBalanceResponse
	if err := json.Unmarshal(body, &resp); err != nil {
		return nil, fmt.Errorf("failed to parse response: %w", err)
	}

	return &resp, nil
}

// GetDIDs - Get all DIDs associated with account
func (v *VoipMsClient) GetDIDs() (*VoipMsDIDsResponse, error) {
	body, err := v.doRequest("getDIDsInfo", nil)
	if err != nil {
		return nil, fmt.Errorf("getDIDsInfo failed: %w", err)
	}

	var resp VoipMsDIDsResponse
	if err := json.Unmarshal(body, &resp); err != nil {
		return nil, fmt.Errorf("failed to parse response: %w", err)
	}

	return &resp, nil
}

// GetNumbers - Get list of phone numbers (for VoiceProvider interface)
func (v *VoipMsClient) GetNumbers() ([]map[string]interface{}, error) {
	dids, err := v.GetDIDs()
	if err != nil {
		return nil, err
	}

	result := make([]map[string]interface{}, len(dids.DIDs))
	for i, did := range dids.DIDs {
		result[i] = map[string]interface{}{
			"number": did.DID,
			"label":  did.Label,
			"routing": did.Routing,
		}
	}

	return result, nil
}

// SendSMS - Send SMS message
// Docs: https://voip.ms/m/apidocs.php (sendSMS method)
func (v *VoipMsClient) SendSMS(from, to, text string) (*VoipMsMessageResponse, error) {
	params := map[string]string{
		"did":  from,
		"dst":  to,
		"msg":  text,
	}

	body, err := v.postRequest("sendSMS", params)
	if err != nil {
		return nil, fmt.Errorf("sendSMS failed: %w", err)
	}

	var resp VoipMsMessageResponse
	if err := json.Unmarshal(body, &resp); err != nil {
		return nil, fmt.Errorf("failed to parse response: %w", err)
	}

	if resp.Status != "success" {
		return nil, fmt.Errorf("voip.ms error: %s", resp.FailedReason)
	}

	return &resp, nil
}

// SetCallerID - Set caller ID presentation for a DID
// Docs: https://voip.ms/m/apidocs.php (setCallerID method)
func (v *VoipMsClient) SetCallerID(did, callerID, callerName string) error {
	params := map[string]string{
		"did":         did,
		"callerid":    callerID,
		"callerid_name": callerName,
	}

	body, err := v.postRequest("setCallerID", params)
	if err != nil {
		return fmt.Errorf("setCallerID failed: %w", err)
	}

	var resp struct {
		Status  string `json:"status"`
		Message string `json:"message"`
	}
	if err := json.Unmarshal(body, &resp); err != nil {
		return fmt.Errorf("failed to parse response: %w", err)
	}

	if resp.Status != "success" {
		return fmt.Errorf("voip.ms error: %s", resp.Message)
	}

	return nil
}

// GetServersInfo - Get voip.ms server information
func (v *VoipMsClient) GetServersInfo() ([]map[string]interface{}, error) {
	body, err := v.doRequest("getServersInfo", nil)
	if err != nil {
		return nil, fmt.Errorf("getServersInfo failed: %w", err)
	}

	var result struct {
		Status  string `json:"status"`
		Servers []struct {
			POP       string `json:"pop"`
			Hostname  string `json:"hostname"`
			IP        string `json:"ip"`
			Weight    string `json:"weight"`
			Available string `json:"available"`
		} `json:"servers"`
	}
	if err := json.Unmarshal(body, &result); err != nil {
		return nil, fmt.Errorf("failed to parse response: %w", err)
	}

	servers := make([]map[string]interface{}, len(result.Servers))
	for i, s := range result.Servers {
		servers[i] = map[string]interface{}{
			"pop":       s.POP,
			"hostname":  s.Hostname,
			"ip":        s.IP,
			"weight":    s.Weight,
			"available":  s.Available,
		}
	}

	return servers, nil
}

// VoipMsAdapter - Adapter to implement VoiceProvider interface
type VoipMsAdapter struct {
	client     *VoipMsClient
	number     string
	callerName string
}

// NewVoipMsAdapter - Creates a new VoipMs adapter
func NewVoipMsAdapter(apiKey, apiSecret, account, number, callerName string) *VoipMsAdapter {
	return &VoipMsAdapter{
		client:     NewVoipMsClient(apiKey, apiSecret, account),
		number:     number,
		callerName: callerName,
	}
}

// ProviderName returns the provider name
func (v *VoipMsAdapter) ProviderName() string {
	return "voipms"
}

// MakeCall implements VoiceProvider interface
func (v *VoipMsAdapter) MakeCall(req CallRequest) (*CallResponse, error) {
	voipmsReq := VoipMsCallRequest{
		From:    req.From,
		To:      req.To,
		Timeout: req.RingTimeout,
	}

	resp, err := v.client.MakeCall(voipmsReq)
	if err != nil {
		return nil, err
	}

	return &CallResponse{
		RequestUUID: resp.CallID,
		UUID:       resp.CallID,
		Message:    resp.Message,
	}, nil
}

// HangupCall implements VoiceProvider interface
func (v *VoipMsAdapter) HangupCall(uuid string) (*PlivoResponse, error) {
	err := v.client.HangupCall(uuid)
	if err != nil {
		return nil, err
	}
	return &PlivoResponse{Message: "hangup"}, nil
}

// GetCallStatus implements VoiceProvider interface
func (v *VoipMsAdapter) GetCallStatus(uuid string) (*CallStatusResponse, error) {
	resp, err := v.client.GetCallStatus(uuid)
	if err != nil {
		return nil, err
	}

	return &CallStatusResponse{
		CallUUID:  resp.CallID,
		CallState: resp.Status,
	}, nil
}

// SendSMS implements VoiceProvider interface
func (v *VoipMsAdapter) SendSMS(from, to, text string) (*PlivoResponse, error) {
	resp, err := v.client.SendSMS(from, to, text)
	if err != nil {
		return nil, err
	}

	return &PlivoResponse{
		Message:  resp.Status,
		APIID:   resp.MessageID,
	}, nil
}

// GetNumbers implements VoiceProvider interface
func (v *VoipMsAdapter) GetNumbers() ([]map[string]interface{}, error) {
	return v.client.GetNumbers()
}

// BuildCallResponseXML - Generate XML for call setup with voice prompts
func (v *VoipMsAdapter) BuildCallResponseXML(greeting, actionURL, confirmation, holdMusic, voice, language string, loops int) string {
	return BuildVoipMsResponse(greeting, actionURL, confirmation, holdMusic, voice, language, loops)
}

// BuildDTMFXML - Generate XML for DTMF collection
func (v *VoipMsAdapter) BuildDTMFXML(message, holdMusic, voice, language string) string {
	return BuildVoipMsDTMFResponse(message, holdMusic, voice, language)
}

// BuildHangupXML - Generate XML for call termination
func (v *VoipMsAdapter) BuildHangupXML(message string) string {
	return BuildVoipMsHangupResponse(message)
}

// BuildRingXML - Generate XML for ring state
func (v *VoipMsAdapter) BuildRingXML() string {
	return BuildVoipMsRingResponse()
}

// BuildMachineXML - Generate XML for answering machine detection
func (v *VoipMsAdapter) BuildMachineXML() string {
	return BuildVoipMsMachineResponse()
}

// BuildVoipMsResponse - Generate XML response for call setup
// voip.ms uses a simplified XML format
func BuildVoipMsResponse(greeting, actionURL, confirmation, holdMusic, voice, language string, loops int) string {
	var xml strings.Builder

	xml.WriteString(`<?xml version="1.0" encoding="UTF-8"?>`)
	xml.WriteString("\n<Response>")

	// Play greeting and collect DTMF
	xml.WriteString("\n  <Play>")
	xml.WriteString(greeting)
	xml.WriteString("</Play>")

	xml.WriteString("\n  <Wait length=\"1\"/>")

	xml.WriteString("\n  <GetDigits timeout=\"15\" finishesOnKey=\"#\" retries=\"2\">")
	xml.WriteString("\n    <Say voice=\"")
	xml.WriteString(voice)
	xml.WriteString("\" language=\"")
	xml.WriteString(language)
	xml.WriteString("\">")
	xml.WriteString(confirmation)
	xml.WriteString("</Say>")
	xml.WriteString("\n  </GetDigits>")

	xml.WriteString("\n  <Say voice=\"")
	xml.WriteString(voice)
	xml.WriteString("\" language=\"")
	xml.WriteString(language)
	xml.WriteString("\">")
	xml.WriteString("No input received. Goodbye.")
	xml.WriteString("</Say>")

	xml.WriteString("\n  <Hangup/>")
	xml.WriteString("\n</Response>")

	return xml.String()
}

// BuildVoipMsDTMFResponse - Generate DTMF collection response
func BuildVoipMsDTMFResponse(message, holdMusic, voice, language string) string {
	var xml strings.Builder

	xml.WriteString(`<?xml version="1.0" encoding="UTF-8"?>`)
	xml.WriteString("\n<Response>")

	xml.WriteString("\n  <Say voice=\"")
	xml.WriteString(voice)
	xml.WriteString("\" language=\"")
	xml.WriteString(language)
	xml.WriteString("\" loop=\"2\">")
	xml.WriteString(message)
	xml.WriteString("</Say>")

	if holdMusic != "" {
		xml.WriteString("\n  <Play>")
		xml.WriteString(holdMusic)
		xml.WriteString("</Play>")
		xml.WriteString("\n  <Wait length=\"10\"/>")
	}

	xml.WriteString("\n</Response>")

	return xml.String()
}

// BuildVoipMsHangupResponse - Generate hangup response
func BuildVoipMsHangupResponse(message string) string {
	var xml strings.Builder

	xml.WriteString(`<?xml version="1.0" encoding="UTF-8"?>`)
	xml.WriteString("\n<Response>")

	if message != "" {
		xml.WriteString("\n  <Say voice=\"female\" language=\"en\">")
		xml.WriteString(message)
		xml.WriteString("</Say>")
	}

	xml.WriteString("\n  <Hangup/>")
	xml.WriteString("\n</Response>")

	return xml.String()
}

// BuildVoipMsRingResponse - Generate ring response
func BuildVoipMsRingResponse() string {
	return `<?xml version="1.0" encoding="UTF-8"?><Response><Dial callee="speak:ringing" timeout="60"></Dial></Response>`
}

// BuildVoipMsMachineResponse - Generate answering machine detection response
func BuildVoipMsMachineResponse() string {
	return `<?xml version="1.0" encoding="UTF-8"?><Response><Hangup reason="CHANUNAVAIL"/></Response>`
}
