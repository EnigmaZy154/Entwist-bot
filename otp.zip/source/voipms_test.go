package voice

import (
	"strings"
	"testing"
)

func TestNewVoipMsClient(t *testing.T) {
	client := NewVoipMsClient("api-key", "api-secret", "account123")

	if client.APIKey != "api-key" {
		t.Errorf("Expected APIKey 'api-key', got '%s'", client.APIKey)
	}

	if client.APISecret != "api-secret" {
		t.Errorf("Expected APISecret 'api-secret', got '%s'", client.APISecret)
	}

	if client.Account != "account123" {
		t.Errorf("Expected Account 'account123', got '%s'", client.Account)
	}

	if client.BaseURL != "https://voip.ms/api/v1/rest.php" {
		t.Errorf("Expected BaseURL, got '%s'", client.BaseURL)
	}

	if client.Client == nil {
		t.Error("Expected HTTP client to be initialized")
	}
}

func TestVoipMsCallRequest(t *testing.T) {
	req := VoipMsCallRequest{
		From:    "+15551234567",
		To:      "+15559876543",
		Timeout: 30,
	}

	if req.From != "+15551234567" {
		t.Errorf("Expected From '+15551234567', got '%s'", req.From)
	}

	if req.To != "+15559876543" {
		t.Errorf("Expected To '+15559876543', got '%s'", req.To)
	}

	if req.Timeout != 30 {
		t.Errorf("Expected Timeout 30, got %d", req.Timeout)
	}
}

func TestVoipMsAdapter(t *testing.T) {
	adapter := NewVoipMsAdapter("api-key", "api-secret", "account", "+15551234567", "Test Caller")

	if adapter.ProviderName() != "voipms" {
		t.Errorf("Expected provider name 'voipms', got '%s'", adapter.ProviderName())
	}

	if adapter.number != "+15551234567" {
		t.Errorf("Expected number '+15551234567', got '%s'", adapter.number)
	}
}

func TestBuildVoipMsResponse(t *testing.T) {
	xml := BuildVoipMsResponse(
		"https://example.com/greeting.mp3",
		"https://example.com/callback",
		"Please enter your code",
		"",
		"female",
		"en",
		1,
	)

	// Check XML structure
	if !strings.Contains(xml, "<?xml version=\"1.0\" encoding=\"UTF-8\"?>") {
		t.Error("XML should contain XML declaration")
	}

	if !strings.Contains(xml, "<Response>") {
		t.Error("XML should contain <Response>")
	}

	if !strings.Contains(xml, "<Play>") {
		t.Error("XML should contain <Play>")
	}

	if !strings.Contains(xml, "https://example.com/greeting.mp3") {
		t.Error("XML should contain greeting URL")
	}

	if !strings.Contains(xml, "<GetDigits") {
		t.Error("XML should contain <GetDigits>")
	}

	if !strings.Contains(xml, "Please enter your code") {
		t.Error("XML should contain confirmation text")
	}

	if !strings.Contains(xml, "</Response>") {
		t.Error("XML should close with </Response>")
	}
}

func TestBuildVoipMsDTMFResponse(t *testing.T) {
	xml := BuildVoipMsDTMFResponse(
		"Please enter your OTP",
		"https://example.com/hold.mp3",
		"female",
		"en",
	)

	if !strings.Contains(xml, "<?xml version=\"1.0\" encoding=\"UTF-8\"?>") {
		t.Error("XML should contain XML declaration")
	}

	if !strings.Contains(xml, "<Response>") {
		t.Error("XML should contain <Response>")
	}

	if !strings.Contains(xml, "<Say") {
		t.Error("XML should contain <Say>")
	}

	if !strings.Contains(xml, "Please enter your OTP") {
		t.Error("XML should contain message")
	}

	if !strings.Contains(xml, "<Play>") {
		t.Error("XML should contain <Play> for hold music")
	}

	if !strings.Contains(xml, "https://example.com/hold.mp3") {
		t.Error("XML should contain hold music URL")
	}
}

func TestBuildVoipMsHangupResponse(t *testing.T) {
	xml := BuildVoipMsHangupResponse("Goodbye")

	if !strings.Contains(xml, "<?xml version=\"1.0\" encoding=\"UTF-8\"?>") {
		t.Error("XML should contain XML declaration")
	}

	if !strings.Contains(xml, "<Response>") {
		t.Error("XML should contain <Response>")
	}

	if !strings.Contains(xml, "Goodbye") {
		t.Error("XML should contain message")
	}

	if !strings.Contains(xml, "<Hangup/>") {
		t.Error("XML should contain <Hangup/>")
	}
}

func TestBuildVoipMsHangupResponseEmpty(t *testing.T) {
	xml := BuildVoipMsHangupResponse("")

	if !strings.Contains(xml, "<Hangup/>") {
		t.Error("XML should contain <Hangup/> even without message")
	}

	// Should not contain <Say> for empty message
	if strings.Contains(xml, "<Say>") {
		t.Error("XML should not contain <Say> for empty message")
	}
}

func TestBuildVoipMsRingResponse(t *testing.T) {
	xml := BuildVoipMsRingResponse()

	if !strings.Contains(xml, "<?xml version=\"1.0\" encoding=\"UTF-8\"?>") {
		t.Error("XML should contain XML declaration")
	}

	if !strings.Contains(xml, "<Response>") {
		t.Error("Ring XML should contain <Response>")
	}
}

func TestBuildVoipMsMachineResponse(t *testing.T) {
	xml := BuildVoipMsMachineResponse()

	if !strings.Contains(xml, "<?xml version=\"1.0\" encoding=\"UTF-8\"?>") {
		t.Error("XML should contain XML declaration")
	}

	if !strings.Contains(xml, "<Hangup") {
		t.Error("Machine XML should contain <Hangup>")
	}
}

func TestVoipMsAdapterMethods(t *testing.T) {
	adapter := NewVoipMsAdapter("api-key", "api-secret", "account", "+15551234567", "Test")

	// Test XML builders return non-empty strings
	ringXML := adapter.BuildRingXML()
	if ringXML == "" {
		t.Error("BuildRingXML should return non-empty XML")
	}

	machineXML := adapter.BuildMachineXML()
	if machineXML == "" {
		t.Error("BuildMachineXML should return non-empty XML")
	}

	hangupXML := adapter.BuildHangupXML("test")
	if hangupXML == "" {
		t.Error("BuildHangupXML should return non-empty XML")
	}

	dtmfXML := adapter.BuildDTMFXML("message", "", "female", "en")
	if dtmfXML == "" {
		t.Error("BuildDTMFXML should return non-empty XML")
	}

	callXML := adapter.BuildCallResponseXML("greeting", "url", "confirm", "", "female", "en", 1)
	if callXML == "" {
		t.Error("BuildCallResponseXML should return non-empty XML")
	}
}

func TestVoipMsCallResponse(t *testing.T) {
	resp := VoipMsCallResponse{
		Status:  "success",
		CallID: "call-123",
		Message: "Call initiated",
	}

	if resp.Status != "success" {
		t.Errorf("Expected Status 'success', got '%s'", resp.Status)
	}

	if resp.CallID != "call-123" {
		t.Errorf("Expected CallID 'call-123', got '%s'", resp.CallID)
	}
}

func TestVoipMsBalanceResponse(t *testing.T) {
	resp := VoipMsBalanceResponse{
		Status:   "success",
		Balance:  "100.50",
		Currency: "USD",
	}

	if resp.Status != "success" {
		t.Errorf("Expected Status 'success', got '%s'", resp.Status)
	}

	if resp.Balance != "100.50" {
		t.Errorf("Expected Balance '100.50', got '%s'", resp.Balance)
	}

	if resp.Currency != "USD" {
		t.Errorf("Expected Currency 'USD', got '%s'", resp.Currency)
	}
}

func TestVoipMsMessageResponse(t *testing.T) {
	resp := VoipMsMessageResponse{
		Status:      "success",
		Deliverable: "true",
		MessageID:   "msg-123",
	}

	if resp.Status != "success" {
		t.Errorf("Expected Status 'success', got '%s'", resp.Status)
	}

	if resp.Deliverable != "true" {
		t.Errorf("Expected Deliverable 'true', got '%s'", resp.Deliverable)
	}
}

func TestProviderVoipMsConstant(t *testing.T) {
	if ProviderVoipMs != "voipms" {
		t.Errorf("Expected ProviderVoipMs to be 'voipms', got '%s'", ProviderVoipMs)
	}
}
